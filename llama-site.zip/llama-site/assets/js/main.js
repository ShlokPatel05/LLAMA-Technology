AOS.init({ duration: 750, once: true, offset: 80 });

if (window.GLightbox) {
  GLightbox({ selector: ".glightbox" });
}
