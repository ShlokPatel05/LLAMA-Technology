<?php
$pageTitle = "Team | LLAMA TECHNOLOGY";
include("includes/header.php");

// Put images in: /llama-site/assets/img/team/
$team = [
  [
    "name" => "Mr. Chetan Gawande",
    "role" => "Director",
    "img"  => "chetan.jpg",
    "bio"  => "Leads LLAMA TECHNOLOGY with a focus on industry-ready training, internships, and career outcomes.",
    "highlights" => [
      "Program strategy & placement partnerships",
      "Quality training delivery & student mentoring",
      "Industry collaboration & client relationships"
    ]
  ],
  [
    "name" => "Mr. Priyam Sharma",
    "role" => "Embedded Trainer",
    "img"  => "priyam.jpg",
    "bio"  => "Specializes in Embedded Systems & IoT with hands-on labs, real hardware projects, and practical workflows.",
    "highlights" => [
      "Embedded C, Arduino/ESP, sensors & actuators",
      "IoT protocols & project development",
      "Industry-style debugging & documentation"
    ]
  ],
  [
    "name" => "Dr. Z. I. Khan",
    "role" => "Programming Languages Expert",
    "img"  => "khan.jpg",
    "bio"  => "An experienced programming languages expert who guides students in building strong coding fundamentals, problem-solving skills, and logical thinking for real-world software development.",
    "highlights" => [
    "C, C++, Java & Python  programming",
    "Data structures, algorithms & logic building",
    "Problem-solving, debugging & coding best practices",
    "Academic concepts aligned with industry use-cases"
    ]
  ],
];

$imgBase = "/llama-site/assets/img/team/";
?>

<section class="section">
  <div class="container">

    <div class="row align-items-end g-3 mb-4">
      <div class="col-lg-7" data-aos="fade-up">
        <span class="badge-soft">Team</span>
        <h1 class="fw-bold mt-3 mb-2">Meet Our Team</h1>
        <p class="text-white-50 mb-0">A dedicated team that focuses on practical learning, mentorship, and career outcomes.</p>
      </div>
      <div class="col-lg-5 text-lg-end" data-aos="fade-up" data-aos-delay="80">
        <a class="btn btn-outline-light rounded-pill" href="/llama-site/register.php">
          Register <i class="bi bi-arrow-right"></i>
        </a>
      </div>
    </div>

    <?php foreach ($team as $idx => $m) {
      $reverse = ($idx % 2 === 1);
      $img = $imgBase . $m['img'];
    ?>

    <div class="cardx mb-4" data-aos="fade-up" data-aos-delay="<?php echo 80 + ($idx*60); ?>">
      <div class="row align-items-center g-4 <?php echo $reverse ? 'flex-lg-row-reverse' : ''; ?>">

        <div class="col-lg-5">
          <div class="team-photo-wrap">
            <img class="team-photo" src="<?php echo $img; ?>" alt="<?php echo htmlspecialchars($m['name']); ?>">
            <div class="team-photo-glow"></div>
          </div>
        </div>

        <div class="col-lg-7">
          <span class="badge-soft"><i class="bi bi-person-badge"></i> <?php echo htmlspecialchars($m['role']); ?></span>

          <h3 class="fw-bold mt-3 mb-1"><?php echo htmlspecialchars($m['name']); ?></h3>
          <p class="text-white-50 mb-3"><?php echo htmlspecialchars($m['bio']); ?></p>

          <div class="row g-2">
            <?php foreach ($m['highlights'] as $h) { ?>
              <div class="col-12 col-md-6">
                <div class="team-point">
                  <i class="bi bi-check2-circle"></i> <?php echo htmlspecialchars($h); ?>
                </div>
              </div>
            <?php } ?>
          </div>

          <div class="mt-3 d-flex gap-2 flex-wrap">
            <a class="btn btn-glow" href="/llama-site/register.php">Enroll <i class="bi bi-arrow-right"></i></a>
            <a class="btn btn-outline-light rounded-pill" href="/llama-site/courses.php">Explore Courses</a>
          </div>
        </div>

      </div>
    </div>

    <?php } ?>

  </div>
</section>

<?php include("includes/footer.php"); ?>
