<?php
$pageTitle="Thank You | LLAMA TECHNOLOGY";
include("includes/header.php");
?>
<section class="section">
  <div class="container">
    <div class="cardx">
      <h3 class="fw-bold">Registration Submitted ✅</h3>
      <p class="text-white-50 mb-0">We will contact you soon.</p>
      <a class="btn btn-glow mt-3" href="/llama-site/">Back to Home</a>
    </div>
  </div>
</section>
<?php include("includes/footer.php"); ?>
